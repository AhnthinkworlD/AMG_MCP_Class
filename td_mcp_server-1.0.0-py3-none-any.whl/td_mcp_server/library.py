"""Versioned accepted components, with thumbnails, source snapshots and asset bindings."""
from .errors import UserError
import base64
import hashlib
import json
import posixpath
import re
import shutil
import uuid
from pathlib import Path
from datetime import datetime, timezone
from . import client, preferences


def _root(context):
    root = Path(context['paths']['library']).resolve()
    if root != (preferences.home() / 'library').resolve():
        raise UserError('Server and TD AMG_HOME differ; use the same AMG_HOME for both processes')
    return root


def register(mcp):
    @mcp.tool()
    def amg_publish_component(comp_path: str, component_id: str, title: str, description: str,
                              preview_top: str, tags: list[str], accepted_by_user: bool = False) -> dict:
        """Store a user-accepted reusable COMP with PNG, snapshot, version and collected file dependencies.
        Native self-contained networks are supported. Dynamic file expressions/external OP references
        must be resolved first; scripts may have dependencies that require manual review.
        """
        if not accepted_by_user:
            raise UserError('Only publish a result the user has accepted; drafts are not learned as successes')
        if not re.fullmatch(r'[a-z][a-z0-9_-]{0,63}', component_id):
            raise UserError('component_id must be a lowercase identifier')
        context = client.call('get_context', {})
        root = _root(context)
        snapshot = client.call('snapshot_v2', {'parent_path': comp_path, 'depth': 8})
        comp_path = snapshot['parent_path']
        if snapshot.get('truncated'):
            raise UserError('Component exceeds snapshot depth; publish a smaller self-contained component')
        if snapshot['nodes'][0]['family'] != 'COMP':
            raise UserError('comp_path must be a COMP')
        status = client.call('validate_network', {'parent_path': comp_path, 'depth': 8})
        if not status['valid']:
            raise UserError('Fix component errors before publishing: ' + json.dumps(status['errors']))
        external = [r for r in snapshot['references'] if not (r['to'] == comp_path or r['to'].startswith(comp_path + '/'))]
        if external:
            raise UserError('Expose external OP references as component inputs before publishing: ' + json.dumps(external))
        assets = []
        for node in snapshot['nodes']:
            for name, par in node['parameters'].items():
                if 'File' not in par.get('style', '') or not par.get('value'):
                    continue
                if not par.get('mode', '').endswith('CONSTANT'):
                    raise UserError('Resolve dynamic file dependency: ' + node['path'] + ':' + name)
                raw = str(par['value'])
                if raw.startswith('amgLibrary://'):
                    source = root / raw[13:]
                else:
                    source = Path(raw)
                    if not source.is_absolute():
                        source = Path(context['paths']['project']) / source
                if not source.is_file():
                    raise UserError('Missing/unresolved file dependency: ' + raw)
                assets.append((node['path'], name, source.resolve()))
        version = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S') + '-' + uuid.uuid4().hex[:8]
        relative = Path(component_id) / version
        folder = root / relative
        folder.mkdir(parents=True, exist_ok=False)
        bindings = []
        for node, param, source in assets:
            digest = hashlib.sha256(source.read_bytes()).hexdigest()
            filename = digest[:20] + source.suffix
            dest = folder / 'assets' / filename
            dest.parent.mkdir(exist_ok=True)
            shutil.copy2(source, dest)
            bindings.append({'node': posixpath.relpath(node, comp_path), 'param': param,
                             'asset': (relative / 'assets' / filename).as_posix(), 'sha256': digest})
        tox = relative / 'component.tox'
        client.call('save_component_tox', {'comp_path': comp_path, 'out_path': 'library://' + tox.as_posix()})
        preview = client.call('capture_top', {'top_path': preview_top})
        (folder / 'preview.png').write_bytes(base64.b64decode(preview['data']))
        manifest = {'id': component_id, 'version': version, 'title': title, 'description': description,
                    'tags': tags, 'accepted_by_user': True, 'td_build': context['td_build'],
                    'tox': tox.as_posix(), 'asset_bindings': bindings, 'snapshot': snapshot,
                    'preview': (relative / 'preview.png').as_posix(), 'warnings': status['warnings'],
                    'dependency_note': 'File parameters collected. Dependencies inside arbitrary scripts require review.'}
        manifest['tox_sha256'] = hashlib.sha256((root / tox).read_bytes()).hexdigest()
        # Manifest is the publication marker, written only after all artifacts exist.
        (folder / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
        return {'id': component_id, 'version': version, 'directory': str(folder), 'dependencies': len(bindings)}

    @mcp.tool()
    def amg_search_components(query: str = '') -> dict:
        """Search accepted reusable components by ID, title, description or tags; no model retraining needed."""
        root = preferences.home() / 'library'
        items = []
        for path in sorted(root.glob('*/*/manifest.json'), reverse=True):
            data = json.loads(path.read_text(encoding='utf-8'))
            if query.casefold() not in json.dumps({k: data[k] for k in ('id', 'title', 'description', 'tags')}, ensure_ascii=False).casefold():
                continue
            items.append({k: data[k] for k in ('id', 'version', 'title', 'description', 'tags', 'td_build', 'preview')})
        return {'components': items[:100]}

    @mcp.tool()
    def amg_insert_component(component_id: str, version: str, parent_path: str, name: str) -> dict:
        """Insert an accepted version, restore its collected file dependencies and validate the result."""
        context = client.call('get_context', {})
        root = _root(context)
        folder = (root / component_id / version).resolve()
        if not folder.is_relative_to(root) or folder == root:
            raise UserError('invalid component path')
        manifest = json.loads((folder / 'manifest.json').read_text(encoding='utf-8'))
        tox = (root / manifest['tox']).resolve()
        if not tox.is_relative_to(root) or hashlib.sha256(tox.read_bytes()).hexdigest() != manifest['tox_sha256']:
            raise UserError('component checksum mismatch')
        for binding in manifest['asset_bindings']:
            path = (root / binding['asset']).resolve()
            if not path.is_relative_to(root) or not path.is_file():
                raise UserError('missing library dependency')
            if binding.get('sha256') and hashlib.sha256(path.read_bytes()).hexdigest() != binding['sha256']:
                raise UserError('library dependency checksum mismatch')
        result = client.call('load_component_tox', {'parent_path': parent_path, 'name': name,
            'tox_path': 'library://' + manifest['tox'], 'asset_bindings': manifest['asset_bindings']})
        validation = client.call('validate_network', {'parent_path': result['path'], 'depth': 8})
        return dict(result, validation=validation, source_build=manifest['td_build'], current_build=context['td_build'])
