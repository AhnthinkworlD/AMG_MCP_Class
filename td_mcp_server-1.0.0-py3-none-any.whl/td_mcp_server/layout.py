"""Deterministic graph layout. No TD imports, model calls, parameter evaluation or cooking."""
import math
from collections import defaultdict
from .errors import UserError


def _scc(vertices, edges):
    """Iterative Kosaraju; long TD chains do not consume Python recursion depth."""
    forward = {v: set() for v in vertices}
    reverse = {v: set() for v in vertices}
    for a, b in edges:
        forward[a].add(b)
        reverse[b].add(a)
    visited, finish = set(), []
    for seed in sorted(vertices):
        if seed in visited:
            continue
        visited.add(seed)
        stack = [(seed, iter(sorted(forward[seed])))]
        while stack:
            node, iterator = stack[-1]
            child = next(iterator, None)
            if child is None:
                finish.append(node)
                stack.pop()
            elif child not in visited:
                visited.add(child)
                stack.append((child, iter(sorted(forward[child]))))
    components, visited = [], set()
    for seed in reversed(finish):
        if seed in visited:
            continue
        component, stack = [], [seed]
        visited.add(seed)
        while stack:
            node = stack.pop()
            component.append(node)
            for child in sorted(reverse[node]):
                if child not in visited:
                    visited.add(child)
                    stack.append(child)
        components.append(sorted(component))
    return components


def _overlaps(a, b, padding=12):
    return (a['x'] < b['x'] + b['width'] + padding and b['x'] < a['x'] + a['width'] + padding
            and a['y'] < b['y'] + b['height'] + padding and b['y'] < a['y'] + a['height'] + padding)


def plan_layout(graph, node_paths=None, pinned_paths=None, direction='horizontal', gap_x=60, gap_y=40):
    """SCC condensation → depth layers → barycenter sweeps → size-aware placement.

    Disconnected networks get separate lanes. Isolated nodes use family-grouped grids.
    Unselected/pinned/protected nodes are fixed obstacles, including the bridge itself.
    """
    if direction not in ('horizontal', 'vertical'):
        raise UserError('direction must be horizontal or vertical')
    for gap in (gap_x, gap_y):
        if isinstance(gap, bool) or not isinstance(gap, (float, int)) or not math.isfinite(gap) or not 0 <= gap <= 2000:
            raise UserError('layout gaps must be finite numbers in 0..2000')
    nodes = {n['path']: n for n in graph['nodes']}
    if len(nodes) > 2000 or len(graph['edges']) > 10000:
        raise UserError('Select a smaller parent: layout supports at most 2000 nodes / 10000 wires')
    selected = set(nodes) if node_paths is None else set(node_paths)
    pinned = set(pinned_paths or [])
    if (selected | pinned) - nodes.keys():
        raise UserError('Selected/pinned nodes must be direct children of this parent')
    protected = {p for p, n in nodes.items() if n.get('protected') or n.get('type') == 'annotate'}
    moving = selected - pinned - protected
    fixed = set(nodes) - moving
    wires = [e for e in graph['edges'] if e['from'] in moving and e['to'] in moving]
    edges = {(e['from'], e['to']) for e in wires}
    components = _scc(moving, edges)
    owner = {p: i for i, group in enumerate(components) for p in group}
    pred = {i: set() for i in range(len(components))}
    succ = {i: set() for i in pred}
    for a, b in edges:
        if owner[a] != owner[b]:
            succ[owner[a]].add(owner[b])
            pred[owner[b]].add(owner[a])
    cycles = [group for group in components if len(group) > 1 or (group[0], group[0]) in edges]
    # Separate weakly connected networks without making the user invent group names.
    networks, unseen = [], set(pred)
    while unseen:
        seed = min(unseen, key=lambda i: components[i][0])
        stack, network = [seed], set()
        unseen.remove(seed)
        while stack:
            i = stack.pop()
            network.add(i)
            for j in sorted((pred[i] | succ[i]) & unseen):
                unseen.remove(j)
                stack.append(j)
        networks.append(network)
    dimensions = {p: (max(1, nodes[p]['width']), max(1, nodes[p]['height'])) for p in moving}
    if direction == 'vertical':
        dimensions = {p: (h, w) for p, (w, h) in dimensions.items()}
    positions, lane, isolated = {}, 0, []
    for network in networks:
        if len(network) == 1 and len(components[next(iter(network))]) == 1 and not any(owner[a] in network for a, b in edges):
            isolated.extend(components[next(iter(network))])
            continue
        rank, remaining = {}, set(network)
        while remaining:
            ready = sorted((i for i in remaining if not (pred[i] & remaining)), key=lambda i: components[i][0])
            if not ready:
                raise UserError('Invalid condensed graph')
            for i in ready:
                rank[i] = max((rank[j] + 1 for j in pred[i]), default=0)
                remaining.remove(i)
        layers = defaultdict(list)
        for i in sorted(network, key=lambda i: components[i][0]):
            layers[rank[i]].append(i)
        # Input/output port order gives stable hints around splits and merges.
        hints = defaultdict(list)
        for edge in wires:
            a, b = owner[edge['from']], owner[edge['to']]
            if a != b and a in network:
                hints[(a, b)].append((edge.get('from_index', 0), edge.get('to_index', 0)))
        for sweep in range(6):
            indices = {i: j for layer in layers.values() for j, i in enumerate(layer)}
            forward = sweep % 2 == 0
            for depth in sorted(layers, reverse=not forward):
                def barycenter(i):
                    adjacent = pred[i] if forward else succ[i]
                    scores = []
                    for j in adjacent:
                        ports = hints[(j, i)] if forward else hints[(i, j)]
                        scores.extend(indices[j] + .01 * (a if forward else b) for a, b in ports)
                    return (sum(scores)/len(scores) if scores else indices[i], indices[i], components[i][0])
                layers[depth].sort(key=barycenter)
                indices.update({i: j for j, i in enumerate(layers[depth])})
        u, extent = 0, 0
        for depth in sorted(layers):
            v, column_width = lane, 0
            for i in layers[depth]:
                for p in components[i]:
                    w, h = dimensions[p]
                    positions[p] = (u, v)
                    v += h + gap_y
                    column_width = max(column_width, w)
            extent = max(extent, v - lane)
            u += column_width + gap_x
        lane += extent + max(80, gap_y * 2)
    # A catalog of unconnected operators should not become a 650-node single column.
    families = defaultdict(list)
    for p in isolated:
        families[nodes[p]['family']].append(p)
    for family in sorted(families):
        group = sorted(families[family])
        cols = min(10, max(1, math.ceil(math.sqrt(len(group)))))
        widths = [max(dimensions[p][0] for p in group[c::cols]) for c in range(cols)]
        for start in range(0, len(group), cols):
            row = group[start:start+cols]
            u = 0
            for col, p in enumerate(row):
                positions[p] = (u, lane)
                u += widths[col] + gap_x
            lane += max(dimensions[p][1] for p in row) + gap_y
        lane += max(80, gap_y * 2)
    anchor_x = min((nodes[p]['x'] for p in moving), default=0)
    anchor_y = max((nodes[p]['y'] + nodes[p]['height'] for p in moving), default=0)
    arranged, obstacles = [], [nodes[p] for p in sorted(fixed)]
    for p, (u, v) in sorted(positions.items(), key=lambda item: (item[1][1], item[1][0], item[0])):
        width, height = nodes[p]['width'], nodes[p]['height']
        rect = {'path': p, 'width': width, 'height': height,
                'x': anchor_x + (u if direction == 'horizontal' else v),
                'y': anchor_y - (v if direction == 'horizontal' else u) - height}
        # Respect manually positioned nodes without changing them. Shift on the cross axis only.
        for _ in range(len(nodes) + 1):
            hits = [n for n in obstacles if _overlaps(rect, n)]
            if not hits:
                break
            if direction == 'horizontal':
                rect['y'] = min(n['y'] for n in hits) - height - max(12, gap_y)
            else:
                rect['x'] = max(n['x'] + n['width'] for n in hits) + max(12, gap_y)
        else:
            raise UserError('Cannot place nodes without overlapping fixed nodes')
        arranged.append(rect)
        obstacles.append(rect)
    return {'parent_path': graph['parent_path'], 'graph_hash': graph['graph_hash'],
            'session_id': graph['session_id'], 'positions': arranged,
            'fixed_paths': sorted(fixed), 'cycles': cycles, 'direction': direction,
            'gap_x': gap_x, 'gap_y': gap_y, 'algorithm': 'scc-layered-barycenter-v1',
            'unresolved_references': graph.get('unresolved_references', []),
            'notes': ['Wires and constant local OP references; parameter expressions are not evaluated.',
                      'Cycle members stay grouped. Crossing reduction is a heuristic, not a global optimum.',
                      'Pinned obstacles can bend the ideal layer order. No cooking or wire edits.']}
