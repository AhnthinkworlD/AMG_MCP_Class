"""Typed tools for the bridge and AMG's persistent workflow layer."""
from .errors import UserError
import asyncio
import json
from typing import Any, Optional, Literal
from mcp.types import ImageContent, TextContent
from . import client, preferences
from .layout import plan_layout


def make_layout_plan(parent_path='.', node_paths=None, pinned_paths=None, direction=None, gap_x=None, gap_y=None):
    context = client.call('get_context', {})
    rules = preferences.read(context['paths']['project'])['effective']
    options = {r['key'].split('.')[1]: r['value'] for r in rules
               if r['key'] in ('layout.gap_x', 'layout.gap_y', 'layout.direction')}
    for key, value in [('direction', direction), ('gap_x', gap_x), ('gap_y', gap_y)]:
        if value is not None:
            options[key] = value
    graph = client.call('get_layout_graph', {'parent_path': parent_path})
    result = plan_layout(graph, node_paths, pinned_paths, **options)
    result['applied_rules'] = [r['key'] for r in rules if r['key'].startswith('layout.')]
    return result


def register(mcp):
    @mcp.tool()
    def td_operator_catalog(mode: Literal['prepare', 'batch', 'status'] = 'status',
                            container_path: str = '', parent_path: str = '.',
                            name: str = 'AMG_ALL_NODES', count: int = 8) -> dict:
        """Create an inventory of all live TD operator types ONLY inside a cooking-disabled container.
        prepare creates the container with Cooking OFF; batch creates at most 10 disconnected nodes;
        status verifies counts/flags without cooking. Initialization scripts and viewers are disabled.
        This is a type inventory, not a functioning example of every operator.
        """
        return client.call('operator_catalog', locals())

    @mcp.tool()
    def td_begin_session() -> dict:
        """Start every TD task here: pin the project/instance and load confirmed user/project preferences."""
        context = client.begin()
        return dict(context, preferences=preferences.read(context['paths']['project']))

    @mcp.tool()
    def amg_build_network(parent_path: str, name: str, nodes: list[dict[str, Any]], connections: list[dict[str, Any]]) -> dict:
        """Assemble a new native network without Python code. nodes=[{name,op_type,parameters:{}}],
        connections=[{source,target,source_index:0,target_index:0}]. Inspect live parameter names first.
        Failed builds remove only the staging COMP. Same specification/name preserves the existing COMP.
        Applies confirmed layout preferences. Use individual edit tools for subsequent changes.
        """
        required = {'get_layout_graph', 'apply_layout_plan'}
        if not required.issubset(client.call('get_capabilities', {})['actions']):
            raise UserError('Load the matching layout-enabled TD bundle before building; nothing was created')
        context = client.call('get_context', {})
        layout = {r['key'].split('.')[1]: r['value'] for r in preferences.read(context['paths']['project'])['effective']
                  if r['key'] in ('layout.gap_x', 'layout.gap_y', 'layout.direction')}
        result = client.call('build_network', {'parent_path': parent_path, 'name': name, 'nodes': nodes,
                                             'connections': connections, 'layout': layout})
        if not result['reused']:
            plan = make_layout_plan(result['path'])
            result['layout'] = client.call('apply_layout_plan', {'plan': plan})
        return result

    @mcp.tool()
    def td_health() -> dict:
        """Get live bridge version, project identity and resolved filesystem roots."""
        return client.call('health', {})

    @mcp.tool()
    def td_get_context() -> dict:
        """Read current network, selected operators, project and instance identity."""
        return client.call('get_context', {})

    @mcp.tool()
    def td_get_capabilities() -> dict:
        """Discover actual supported actions/operator types; never guess runtime support."""
        return client.call('get_capabilities', {})

    @mcp.tool()
    def td_list_operator_symbols(family: str = 'TOP') -> dict:
        """Read TD's operator symbols; get_capabilities lists the subset permitted for creation."""
        return client.call('list_operator_symbols', {'family': family})

    @mcp.tool()
    def td_list_params(node_path: str) -> dict:
        """Read exact parameter names, types and menu values before editing unfamiliar nodes."""
        return client.call('list_params', {'node_path': node_path})

    @mcp.tool()
    def td_get_param_menu(node_path: str, param: str) -> dict:
        """Read internal menu values and human-readable labels."""
        return client.call('get_param_menu', {'node_path': node_path, 'param': param})

    @mcp.tool()
    def td_get_operator_status(node_path: str) -> dict:
        """Cook one operator and return errors/warnings; does not prove visual correctness."""
        return client.call('get_operator_status', {'node_path': node_path})

    @mcp.tool()
    def td_get_chop_channels(node_path: str) -> dict:
        """Discover actual channel names and sampled values before linking controls."""
        return client.call('get_chop_channels', {'node_path': node_path})

    @mcp.tool()
    def td_get_dat_text(node_path: str, offset: int = 0, max_chars: int = 8192) -> dict:
        """Read bounded DAT text before editing; never run its contents."""
        return client.call('get_dat_text', locals())

    @mcp.tool()
    def td_set_dat_text(node_path: str, text: str) -> dict:
        """Replace DAT text. Prefer native nodes; callbacks/shaders may execute when TD uses the DAT."""
        return client.call('set_dat_text', locals())

    @mcp.tool()
    def td_set_table_rows(node_path: str, rows: list[list[Any]]) -> dict:
        """Replace a Table DAT with literal rows."""
        return client.call('set_table_rows', locals())

    @mcp.tool()
    def td_copy_node(node_path: str, new_parent_path: str, name: Optional[str] = None) -> dict:
        """Reuse a validated node/COMP without destroying the source; verify external references."""
        return client.call('copy_node', {k: v for k, v in locals().items() if v is not None})

    @mcp.tool()
    def td_load_component_tox(parent_path: str, tox_path: str, name: Optional[str] = None) -> dict:
        """Load a component from project .amg/components or library://. Prefer reusable components."""
        return client.call('load_component_tox', {k: v for k, v in locals().items() if v is not None})

    @mcp.tool()
    def td_save_component_tox(comp_path: str, out_path: str) -> dict:
        """Export a component. Relative output paths resolve inside this project's .amg/components."""
        return client.call('save_component_tox', locals())

    @mcp.tool()
    def td_get_td_version() -> dict:
        """Get running TouchDesigner version/build."""
        return client.call('get_td_version', {})

    @mcp.tool()
    def td_save_amg_mcp_project() -> dict:
        """Schedule a unique TOE beside the current project, preserving the folder for relative assets.
        TD Save As changes the active filename: wait for the file, then td_begin_session before editing.
        """
        return client.call('save_amg_mcp_project', {})

    @mcp.tool()
    def td_set_node_position(node_path: str, x: float, y: float, width: Optional[float] = None, height: Optional[float] = None) -> dict:
        """Set an explicit node position/size, preserving other nodes."""
        return client.call('set_node_position', {k: v for k, v in locals().items() if v is not None})

    @mcp.tool()
    def td_set_param_chop_ref(node_path: str, param: str, chop_path: str, channel: str) -> dict:
        """Link a parameter to a verified CHOP channel using a relocatable relative expression."""
        return client.call('set_param_chop_ref', locals())

    @mcp.tool()
    def td_set_param_sine(node_path: str, param: str, amp: float, freq: float, phase: float = 0) -> dict:
        """Apply the approved sine animation template; freq is radians per second."""
        return client.call('set_param_sine', locals())

    @mcp.tool()
    def td_set_param_time_wrap(node_path: str, param: str, period: float, scale: float) -> dict:
        """Apply a bounded time animation template. period must be positive."""
        return client.call('set_param_time_wrap', locals())

    @mcp.tool()
    def td_pulse_param(node_path: str, param: str) -> dict:
        """Pulse an allowed Add SOP sequence control (point/poly)."""
        return client.call('pulse_param', locals())

    @mcp.tool()
    def td_set_sequence_blocks(node_path: str, sequence: str, count: int) -> dict:
        """Set the allowed Add SOP point/poly sequence length."""
        return client.call('set_sequence_blocks', locals())

    @mcp.tool()
    def td_snapshot_v2(parent_path: str = '.', depth: int = 2) -> dict:
        """Inspect hierarchy, nondefault parameters, expressions, flags, positions and references."""
        return client.call('snapshot_v2', locals())

    @mcp.tool()
    def td_validate_network(parent_path: str = '.', depth: int = 2) -> dict:
        """Report actual operator errors/warnings and CPU cook times. Follow with visual preview."""
        return client.call('validate_network', locals())

    @mcp.tool(structured_output=False)
    async def td_preview_top(top_path: str, frames: int = 1, interval_seconds: float = 0.25) -> list:
        """Return actual PNG image content to vision-capable clients. Use 2..6 frames for motion."""
        if not 1 <= frames <= 6 or not 0.05 <= interval_seconds <= 2:
            raise UserError('frames must be 1..6 and interval_seconds 0.05..2')
        content = []
        for index in range(frames):
            if index:
                await asyncio.sleep(interval_seconds)
            result = await asyncio.to_thread(client.call, 'capture_top', {'top_path': top_path})
            data = result.pop('data')
            content.extend([TextContent(type='text', text=json.dumps(result, ensure_ascii=False)),
                            ImageContent(type='image', data=data, mimeType=result['mime_type'])])
        return content

    @mcp.tool()
    def amg_record_preference(key: str, text: str, source: str, value: Any = None,
                              scope: Literal['user', 'project'] = 'project',
                              status: Literal['confirmed', 'candidate', 'retired'] = 'candidate') -> dict:
        """Persist user feedback with provenance. Explicit general preferences may be user/confirmed;
        inferred ones stay candidate. 'This project' stays project-scoped. Never invent consent.
        Supported automatic settings: layout.gap_x, layout.gap_y, layout.direction. Other keys guide the agent.
        """
        folder = client.call('get_context', {})['paths']['project'] if scope == 'project' else None
        return preferences.record(key, text, source, value, scope, status, folder)

    @mcp.tool()
    def amg_get_preferences(query: str = '', include_project: bool = True) -> dict:
        """Load effective confirmed rules and separate candidates; project rules override global rules."""
        folder = client.call('get_context', {})['paths']['project'] if include_project else None
        return preferences.read(folder, query)

    @mcp.tool()
    def amg_preference_history(key: str, scope: Literal['user', 'project'] = 'user') -> dict:
        """Read the durable revision history of a workflow preference."""
        folder = client.call('get_context', {})['paths']['project'] if scope == 'project' else None
        return {'history': preferences.history(key, scope, folder)}

    @mcp.tool()
    def amg_plan_layout(parent_path: str = '.', node_paths: Optional[list[str]] = None,
                        pinned_paths: Optional[list[str]] = None, direction: Optional[str] = None,
                        gap_x: Optional[float] = None, gap_y: Optional[float] = None) -> dict:
        """Preview a layout without moving/cooking nodes. SCC cycle groups, wire layers, crossing-reduction
        sweeps, family grids for isolated nodes, fixed-node obstacles. Uses confirmed layout preferences.
        Pass the returned plan unchanged to amg_apply_layout(plan=...). Expressions are not evaluated.
        """
        return make_layout_plan(parent_path, node_paths, pinned_paths, direction, gap_x, gap_y)

    @mcp.tool()
    def amg_apply_layout(parent_path: str = '.', node_paths: Optional[list[str]] = None,
                         pinned_paths: Optional[list[str]] = None, direction: Optional[str] = None,
                         gap_x: Optional[float] = None, gap_y: Optional[float] = None,
                         plan: Optional[dict[str, Any]] = None) -> dict:
        """Apply a previewed plan, or compute/apply with confirmed preferences. Does not cook or reconnect.
        Pinned/unselected nodes remain fixed. A plan is rejected if nodes, wires or positions changed.
        Use amg_undo_layout for the most recent layout while the network remains unchanged.
        """
        if plan is None:
            plan = make_layout_plan(parent_path, node_paths, pinned_paths, direction, gap_x, gap_y)
        return dict(client.call('apply_layout_plan', {'plan': plan}), applied_rules=plan.get('applied_rules', []))

    @mcp.tool()
    def amg_undo_layout(parent_path: str = '.') -> dict:
        """Restore positions before the most recent AMG layout. Rejects intervening network edits.
        A second call toggles back to the layout; this is not a multi-step undo history.
        """
        return client.call('undo_layout', {'parent_path': parent_path})

    from .library import register as register_library
    register_library(mcp)
