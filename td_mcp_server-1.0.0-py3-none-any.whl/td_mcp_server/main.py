"""TD-MCP: an MCP stdio server that proxies to a running TouchDesigner instance.

TouchDesigner must already be running with the `control` component set up
(see ../td-side/README.md) before any of these tools will succeed.
"""

from typing import Optional, Any

from mcp.server.mcpserver import MCPServer

from . import client

mcp = MCPServer("AMG-MCP", version="1.0.0", log_level="WARNING", instructions=(
    "Start TD work with td_begin_session. Read its confirmed workflow preferences and live capabilities. "
    "Inspect td_list_params/menu names before changing unfamiliar parameters. Prefer existing components "
    "and native nodes; do not write HTTP helper scripts or guess parameter names. After edits use "
    "td_validate_network and td_preview_top; inspect the actual images, including multiple frames for motion. "
    "Record explicit user feedback with amg_record_preference, preserving its scope and source. "
    "Inferred preferences remain candidates. Read relevant preferences on every new project. "
    "Use amg_apply_layout for confirmed layout settings. Publish reusable components only when the user "
    "has accepted their result. Never treat a successful tool call as proof of visual quality."
))


@mcp.tool()
def td_create_node(parent_path: str, op_type: str, name: str) -> dict:
    """Create a new TouchDesigner node under parent_path.

    op_type must be one of the whitelisted type names configured on the TD side
    (dispatcher.py's ALLOWED_OP_TYPES), e.g. "noiseTOP", "sphereSOP", "geometryCOMP".
    """
    return client.call("create_node", {"parent_path": parent_path, "op_type": op_type, "name": name})


@mcp.tool()
def td_set_param(node_path: str, param: str, value: Any, is_expr: bool = False) -> dict:
    """Set one parameter on a node.

    param is the parameter's short Python name (e.g. "period", "translatex").
    Literal values are supported. The current TD dispatcher deliberately rejects
    ``is_expr=True`` because arbitrary expression evaluation is disabled; callers
    must not assume expression binding is available.
    """
    return client.call(
        "set_param", {"node_path": node_path, "param": param, "value": value, "is_expr": is_expr}
    )


@mcp.tool()
def td_set_flag(node_path: str, flag: str, on: bool) -> dict:
    """Toggle a node flag: one of display, viewer, bypass, render, lock."""
    return client.call("set_flag", {"node_path": node_path, "flag": flag, "on": on})


@mcp.tool()
def td_connect(src_path: str, dst_path: str, src_out_index: int = 0, dst_in_index: int = 0) -> dict:
    """Wire src_path's output to dst_path's input. Both must be the same operator family."""
    return client.call(
        "connect",
        {
            "src_path": src_path,
            "dst_path": dst_path,
            "src_out_index": src_out_index,
            "dst_in_index": dst_in_index,
        },
    )


@mcp.tool()
def td_disconnect(dst_path: str, dst_in_index: int = 0) -> dict:
    """Remove the wire feeding dst_path's given input index."""
    return client.call("disconnect", {"dst_path": dst_path, "dst_in_index": dst_in_index})


@mcp.tool()
def td_delete_node(node_path: str) -> dict:
    """Delete a node."""
    return client.call("delete_node", {"node_path": node_path})


@mcp.tool()
def td_move_node(node_path: str, new_parent_path: str, name: Optional[str] = None) -> dict:
    """Move a node to another COMP by copying it and deleting the original.

    This preserves the copied node's internal wiring and parameters, but absolute
    path expressions or external references may still point at the old location.
    Verify the result with td_get_network_snapshot before moving more nodes.
    """
    args = {"node_path": node_path, "new_parent_path": new_parent_path}
    if name is not None:
        args["name"] = name
    return client.call("move_node", args)


@mcp.tool()
def td_list_children(parent_path: str) -> dict:
    """List the direct children of a COMP, with each child's type and family."""
    return client.call("list_children", {"parent_path": parent_path})


@mcp.tool()
def td_get_param(node_path: str, param: str) -> dict:
    """Read a node parameter's current evaluated value."""
    return client.call("get_param", {"node_path": node_path, "param": param})


@mcp.tool()
def td_save_top_image(top_path: str, out_path: str, format: Optional[str] = None) -> dict:
    """Save a TOP's current rendered frame to an image file (png/jpg/tiff/bmp/exr/dds).

    out_path must be inside the TD-side dispatcher's configured OUTPUT_DIR.
    """
    return client.call("save_top_image", {"top_path": top_path, "out_path": out_path, "format": format})


@mcp.tool()
def td_get_network_snapshot(parent_path: str) -> dict:
    """Read back the node/wire structure under parent_path.

    A structural (not visual) substitute for a Network Editor screenshot — for
    an actual pixel screenshot of the editor window itself, use td_capture_screenshot.
    """
    return client.call("get_network_snapshot", {"parent_path": parent_path})


@mcp.tool()
def td_layout_nodes(parent_path: str, gap_x: int = 60, gap_y: int = 40) -> dict:
    """Auto-arrange parent_path's direct children left-to-right by wire depth.

    Source nodes (no inputs) go in column 0; each downstream node is placed one
    column to the right of its furthest-upstream wired input. Parameter-based
    references (e.g. Feedback TOP's Top par) are not wires and don't affect layout.
    Useful right after building a network via td_create_node/td_connect so the
    network editor is readable without manual dragging.
    """
    return client.call("layout_nodes", {"parent_path": parent_path, "gap_x": gap_x, "gap_y": gap_y})


@mcp.tool()
def td_capture_screenshot(out_path: str) -> dict:
    """Capture an actual screenshot of the TouchDesigner window (PNG or BMP by extension).

    Unlike td_save_top_image (which renders one TOP's pixels), this captures the
    real editor UI as currently shown on screen — node boxes, wires, parameter
    panels, timeline. out_path must be inside the TD-side dispatcher's OUTPUT_DIR.
    Uses PrintWindow, so the TD window does not need to be focused or unobstructed,
    but it must not be minimized.
    """
    return client.call("capture_screenshot", {"out_path": out_path})


@mcp.tool()
def td_simulate_click(x: int, y: int, button: str = "left") -> dict:
    """Click at (x, y) client-area coordinates inside the TouchDesigner window.

    Brings TD to the foreground first. Coordinates are relative to the TD window's
    client area (same frame you'd see in td_capture_screenshot), not the screen.
    button is "left" or "right". Use for GUI-only actions with no op/par equivalent
    (e.g. dragging from the Palette browser) — prefer td_create_node/td_set_param
    for anything expressible through the normal API.
    """
    return client.call("simulate_click", {"x": x, "y": y, "button": button})


@mcp.tool()
def td_simulate_text(text: str) -> dict:
    """Type a unicode string into whatever currently has focus in the TouchDesigner window.

    Brings TD to the foreground first. Usually follows a td_simulate_click on a
    text field. Refuses to send to any window other than TouchDesigner's.
    """
    return client.call("simulate_text", {"text": text})


@mcp.tool()
def td_simulate_key(key: str) -> dict:
    """Send one named special key to the TouchDesigner window (enter, tab, escape,
    backspace, delete, up, down, left, right)."""
    return client.call("simulate_key", {"key": key})


@mcp.tool()
def td_get_node_positions(node_paths: list[str]) -> dict:
    """Read current network-editor nodeX/nodeY/nodeWidth/nodeHeight for a list of nodes.

    Read-only — makes no changes. Useful for computing a bounding box before
    calling td_add_annotation to draw a label box around a group of nodes.
    """
    return client.call("get_node_positions", {"node_paths": node_paths})


@mcp.tool()
def td_add_annotation(parent_path: str, name: str, title: str, x: float, y: float,
                       width: float, height: float, body: Optional[str] = None) -> dict:
    """Create an Annotate COMP as a labeled box at the given network-editor position/size.

    Plain label/comment box — does NOT enable Annotate's "Utility" mode (found to
    silently rename the node on this TD build, so it's avoided). Compute x/y/width/
    height from td_get_node_positions (or td_layout_nodes' returned positions) to
    size the box around a specific group of nodes.
    """
    return client.call(
        "add_annotation",
        {"parent_path": parent_path, "name": name, "title": title, "x": x, "y": y,
         "width": width, "height": height, "body": body},
    )


from .extended import register
register(mcp)


def run():
    mcp.run(transport="stdio")


if __name__ == "__main__":
    run()
