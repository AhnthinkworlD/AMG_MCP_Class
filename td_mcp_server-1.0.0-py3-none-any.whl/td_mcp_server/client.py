"""HTTP client that relays commands to the Web Server DAT running inside TouchDesigner."""

import os
import time
import httpx
from mcp.server.mcpserver.exceptions import ToolError

TD_URL = os.environ.get("TD_MCP_URL", "http://127.0.0.1:9981/")
TIMEOUT = float(os.environ.get("TD_MCP_TIMEOUT", "10"))

# TD's Web Server DAT briefly stops responding whenever TD itself stops cooking
# (most commonly: Windows + "Stop Playing when Minimized" preference left on).
# A couple of short retries absorbs that transient case without making a truly
# dead TD hang for a long time.
RETRY_ATTEMPTS = int(os.environ.get("TD_MCP_RETRY_ATTEMPTS", "2"))
RETRY_DELAY = float(os.environ.get("TD_MCP_RETRY_DELAY", "0.75"))
READ_ONLY_ACTIONS = {"health", "get_context", "get_capabilities", "list_children", "get_param", "get_network_snapshot", "get_node_positions", "get_dat_text", "list_params", "get_param_menu", "get_td_version", "list_operator_symbols", "snapshot_v2", "validate_network"}
_session = None
READ_ONLY_ACTIONS.add('get_layout_graph')
_supported = set()


class TDError(ToolError):
    pass


def call(action: str, args: dict) -> dict:
    """POST one action to the TD-side dispatcher and return its `result`.

    Retries a couple of times on connection failure (TD's Web Server DAT can
    stop responding for a moment while TD itself isn't cooking), then raises
    TDError if TD is still unreachable, or if the dispatcher reports ok=false.
    """
    discovery = action in {"health", "get_context", "get_capabilities"}
    if not discovery and _session is None:
        begin()
    if not discovery and action not in _supported:
        raise TDError('Action not supported by the active TD bundle: ' + action)
    if _session and not discovery:
        args = dict(args, _expected_session=_session)
    attempts = RETRY_ATTEMPTS if action in READ_ONLY_ACTIONS else 0
    for attempt in range(attempts + 1):
        try:
            resp = httpx.post(TD_URL, json={"action": action, "args": args}, timeout=TIMEOUT)
            resp.raise_for_status()
            break
        except httpx.HTTPError as e:
            if attempt < attempts:
                time.sleep(RETRY_DELAY)
                continue
            raise TDError(
                f"TouchDesigner에 연결할 수 없습니다 ({TD_URL}). "
                f"TD가 실행 중이고 control 컴포넌트의 Web Server DAT가 켜져 있는지 확인하세요. "
                f"TD가 최소화된 상태라면 Preferences의 'Stop Playing when Minimized'가 꺼져있는지도 "
                f"확인하세요. 원인: {e}"
            ) from e

    try:
        payload = resp.json()
    except ValueError as e:
        raise TDError(f"TD로부터 JSON이 아닌 응답을 받았습니다: {resp.text[:200]}") from e

    if not payload.get("ok"):
        raise TDError(payload.get("error", "알 수 없는 TD 쪽 오류"))
    return payload.get("result", {})


def begin() -> dict:
    global _session, _supported
    context = call('health', {})
    capabilities = call('get_capabilities', {})
    if context.get('protocol_version') != 2 or capabilities.get('protocol_version') != 2:
        raise TDError('AMG runtime v1.0 (protocol 2) required. Load the new AMG_MCP.tox first.')
    _session = context['session_id']
    _supported = set(capabilities['actions'])
    return dict(context, capabilities=capabilities)
