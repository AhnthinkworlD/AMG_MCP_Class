"""Durable user feedback. SQLite transactions preserve history across MCP clients."""
from .errors import UserError
import json
import os
import re
import sqlite3
from pathlib import Path
from datetime import datetime, timezone


def home():
    return Path(os.environ.get('AMG_HOME', str(Path.home() / '.amg-mcp'))).resolve()


def _database(scope, project_folder):
    if scope == 'user':
        return home() / 'preferences.sqlite3'
    if scope != 'project' or not project_folder:
        raise UserError('scope must be user or project; project requires an active TD project')
    return Path(project_folder) / '.amg' / 'preferences.sqlite3'


def _connect(path):
    path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(path, timeout=10)
    con.row_factory = sqlite3.Row
    con.executescript('''
        CREATE TABLE IF NOT EXISTS rules (key TEXT PRIMARY KEY, text TEXT NOT NULL,
            value TEXT NOT NULL, status TEXT NOT NULL, source TEXT NOT NULL, updated TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS history (id INTEGER PRIMARY KEY AUTOINCREMENT,
            key TEXT NOT NULL, record TEXT NOT NULL, updated TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS candidates (key TEXT PRIMARY KEY, text TEXT NOT NULL,
            value TEXT NOT NULL, status TEXT NOT NULL, source TEXT NOT NULL, updated TEXT NOT NULL);
    ''')
    return con


def record(key, text, source, value=None, scope='project', status='candidate', project_folder=None):
    if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_.-]{0,99}', key):
        raise UserError('key must be a stable ASCII identifier, e.g. layout.direction')
    if not text.strip() or not source.strip():
        raise UserError('text and source user statement/evidence are required')
    if status not in ('confirmed', 'candidate', 'retired'):
        raise UserError('invalid status')
    if key in ('layout.gap_x', 'layout.gap_y') and (isinstance(value, bool) or not isinstance(value, (int, float)) or not 0 <= value <= 2000):
        raise UserError('layout gap must be 0..2000')
    if key == 'layout.direction' and value not in ('horizontal', 'vertical'):
        raise UserError('layout.direction must be horizontal or vertical')
    encoded = json.dumps(value, ensure_ascii=False, allow_nan=False)
    if len(text) + len(source) + len(encoded) > 20000:
        raise UserError('preference too large')
    now = datetime.now(timezone.utc).isoformat()
    data = dict(key=key, text=text, value=value, status=status, source=source, updated=now, scope=scope)
    con = _connect(_database(scope, project_folder))
    try:
        with con:
            table = 'candidates' if status == 'candidate' else 'rules'
            con.execute('INSERT OR REPLACE INTO ' + table + ' VALUES (?, ?, ?, ?, ?, ?)', (key, text, encoded, status, source, now))
            if status != 'candidate':
                con.execute('DELETE FROM candidates WHERE key=?', (key,))
            con.execute('INSERT INTO history(key, record, updated) VALUES (?, ?, ?)', (key, json.dumps(data, ensure_ascii=False), now))
    finally:
        con.close()
    return data


def read(project_folder=None, query=''):
    effective, candidates, records = {}, [], []
    for scope in ('user', 'project'):
        if scope == 'project' and not project_folder:
            continue
        path = _database(scope, project_folder)
        if not path.exists():
            continue
        con = _connect(path)
        try:
            rows = con.execute('SELECT * FROM rules ORDER BY key').fetchall()
            rows += con.execute('SELECT * FROM candidates ORDER BY key').fetchall()
        finally:
            con.close()
        for row in rows:
            data = dict(row, scope=scope)
            data['value'] = json.loads(data['value'])
            records.append(data)
            if data['status'] == 'confirmed':
                effective[data['key']] = data
            elif data['status'] == 'retired':
                # A project retirement can explicitly suppress a global rule.
                effective.pop(data['key'], None)
            else:
                candidates.append(data)
    def relevant(row):
        return not query or query.casefold() in (row['key'] + ' ' + row['text']).casefold()
    return {'effective': [v for v in effective.values() if relevant(v)],
            'candidates': [v for v in candidates if relevant(v)],
            'records': [v for v in records if relevant(v)]}


def history(key, scope='user', project_folder=None):
    path = _database(scope, project_folder)
    if not path.exists():
        return []
    con = _connect(path)
    try:
        return [json.loads(row[0]) for row in con.execute('SELECT record FROM history WHERE key=? ORDER BY id', (key,))]
    finally:
        con.close()
