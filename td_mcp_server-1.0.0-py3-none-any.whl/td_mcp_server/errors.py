from mcp.server.mcpserver.exceptions import ToolError


class UserError(ToolError, ValueError):
    """An expected, actionable validation failure that MCP may disclose to its caller."""
